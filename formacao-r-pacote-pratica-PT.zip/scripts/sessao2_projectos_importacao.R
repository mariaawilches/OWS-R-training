# ==============================================================
# Sessão 2: Projectos, pacotes e importação de dados
# Antes de executar: abra o projecto do RStudio formacao-r.Rproj
# (File > Open Project) para que a pasta dados/ seja encontrada.
# ==============================================================

# 1. Instalar pacotes (só UMA vez por computador; precisa de internet) ---
# Retire o # do início da linha seguinte na primeira vez que a executar.
# install.packages(c("tidyverse", "readxl", "writexl"))

# 2. Carregar pacotes (SEMPRE que abrir o R) ------------------------
library(tidyverse)   # inclui readr, dplyr, ggplot2, tidyr, forcats...
library(readxl)      # para ler ficheiros Excel

# 3. Onde estou? -------------------------------------------------------
getwd()               # o directório de trabalho (a pasta do projecto)
list.files("dados")   # ficheiros dentro da pasta dados

# 4. Importar um ficheiro CSV -------------------------------------------
inquerito <- read_csv("dados/inquerito_escolar_ficticio.csv")

# 5. Olhar para os dados -------------------------------------------------
inquerito           # mostra as primeiras linhas
glimpse(inquerito)  # uma linha por variável, com o seu tipo
View(inquerito)     # abre um visualizador tipo folha de cálculo (não edite aí)
nrow(inquerito); ncol(inquerito)
names(inquerito)

# 6. Importar um ficheiro Excel -------------------------------------------
excel_sheets("dados/inquerito_escolar_ficticio_desorganizado.xlsx")   # lista as folhas
desorg_ch <- read_excel("dados/inquerito_escolar_ficticio_desorganizado.xlsx",
                        sheet = "Chamanculo C")
glimpse(desorg_ch)  # repare nos nomes longos das colunas e em texto em colunas numéricas

# 7. Importar a segunda tabela (medidas) ----------------------------------
medidas <- read_csv("dados/medidas_ficticias.csv")
glimpse(medidas)

# ==============================================================
# EXERCÍCIOS
# 1. Importe a folha "Macaneta" do ficheiro Excel desorganizado para um objecto chamado desorg_mc.
# 2. Quantas linhas e colunas tem?
# 3. Que colunas foram lidas como texto (<chr>) quando deviam ser números? Porquê?
# 4. Use o sinal $ para extrair a coluna idade de inquerito e calcule a sua média.
# ==============================================================

# SOLUÇÕES
desorg_mc <- read_excel("dados/inquerito_escolar_ficticio_desorganizado.xlsx", sheet = "Macaneta")
dim(desorg_mc)
glimpse(desorg_mc)  # p. ex. "Distância à escola (km)" contém "-", bem-estar contém 99
mean(inquerito$idade)
