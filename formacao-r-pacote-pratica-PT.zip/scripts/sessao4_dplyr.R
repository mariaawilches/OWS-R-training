# ==============================================================
# Sessão 4: Gestão de bases de dados com dplyr
# O operador |> (pipe) lê-se "e depois". Atalho: Ctrl+Shift+M
# ==============================================================
library(tidyverse)
inquerito <- read_csv("dados/inquerito_escolar_ficticio.csv")
medidas   <- read_csv("dados/medidas_ficticias.csv")

# 1. select(): escolher colunas ---------------------------------------------
inquerito |> select(id, local, sexo, modo_transporte)
inquerito |> select(-data_inquerito)          # tudo excepto data_inquerito

# 2. filter(): escolher linhas -------------------------------------------------
inquerito |> filter(local == "Macaneta")
inquerito |> filter(modo_transporte == "A pé", distancia_km > 2)
inquerito |> filter(modo_transporte %in% c("Bicicleta", "A pé"))
inquerito |> filter(!is.na(bem_estar))

# 3. arrange(): ordenar linhas -------------------------------------------------
inquerito |> arrange(desc(tempo_viagem_min))

# 4. mutate(): criar ou alterar colunas ------------------------------------------
inquerito <- inquerito |>
  mutate(velocidade_kmh = distancia_km / (tempo_viagem_min / 60),
         activo         = if_else(modo_transporte %in% c("A pé", "Bicicleta"),
                                  "Activo", "Não activo"),
         grupo_idade    = case_when(idade <= 12 ~ "10-12",
                                    idade <= 15 ~ "13-15",
                                    TRUE        ~ "16-18"))

# 5. count(), group_by() e summarise() ---------------------------------------------
inquerito |> count(local, modo_transporte)
inquerito |> count(local, activo) |>
  group_by(local) |>
  mutate(percentagem = round(100 * n / sum(n), 1))

inquerito |>
  group_by(local, sexo) |>
  summarise(alunos            = n(),
            distancia_media   = mean(distancia_km, na.rm = TRUE),
            tempo_mediano     = median(tempo_viagem_min),
            bem_estar_medio   = mean(bem_estar, na.rm = TRUE),
            .groups = "drop")

# 6. Junções (joins): combinar duas tabelas através de uma chave (id) -------------
nrow(inquerito); nrow(medidas)
ambos <- inquerito |> inner_join(medidas, by = "id")        # só IDs presentes nas duas tabelas
todos <- inquerito |> left_join(medidas, by = "id")         # todas as linhas do inquérito; NA se não houver medidas
sem_inquerito <- medidas |> anti_join(inquerito, by = "id") # medidas sem registo no inquérito
sem_inquerito

todos <- todos |>
  mutate(imc = peso_kg / (altura_cm / 100)^2)   # índice de massa corporal
summary(todos$imc)

# ==============================================================
# EXERCÍCIOS
# 1. Fique só com as raparigas de Chamanculo C que vão de chapa. Quantas são?
# 2. Crie a variável tempo_cat: "Até 15 min", "16-30 min", "Mais de 30 min".
# 3. Para cada modo de transporte, calcule o número de alunos e o tempo médio de viagem.
#    Ordene do maior para o menor tempo médio.
# 4. Quantos alunos do inquérito não têm medidas? (Dica: is.na(altura_cm))
# ==============================================================

# SOLUÇÕES
inquerito |> filter(local == "Chamanculo C", sexo == "Rapariga", modo_transporte == "Chapa") |> nrow()
inquerito <- inquerito |>
  mutate(tempo_cat = case_when(tempo_viagem_min <= 15 ~ "Até 15 min",
                               tempo_viagem_min <= 30 ~ "16-30 min",
                               TRUE                   ~ "Mais de 30 min"))
inquerito |> count(tempo_cat)
inquerito |>
  group_by(modo_transporte) |>
  summarise(alunos = n(), tempo_medio = mean(tempo_viagem_min)) |>
  arrange(desc(tempo_medio))
sum(is.na(todos$altura_cm))
