# ==============================================================
# Sessão 1: Primeiros passos no R e no RStudio
# Formação em R da equipa OWS Moçambique (script de prática)
# Execute cada linha com Ctrl+Enter (Windows) ou Cmd+Enter (Mac).
# As linhas que começam com # são comentários: o R ignora-as.
# ==============================================================

# 1. O R como calculadora ------------------------------------------
2 + 3
10 / 4
(5 + 3) * 2
sqrt(81)          # raiz quadrada
15 %% 4           # resto de uma divisão

# 2. Objectos: guardar valores com <- --------------------------------
alunos <- 240
raparigas <- 117
raparigas / alunos             # proporção de raparigas
prop_raparigas <- raparigas / alunos
round(prop_raparigas * 100, 1) # percentagem, com 1 casa decimal

# 3. Vectores: vários valores num só objecto -----------------------
idades <- c(13, 14, 14, 15, 17, 16, 13)
length(idades)   # quantos valores
mean(idades)     # média
median(idades)   # mediana
min(idades); max(idades)
idades + 1       # as operações aplicam-se a cada valor

modos <- c("A pé", "A pé", "Chapa", "Bicicleta", "A pé")
table(modos)     # frequência de cada categoria

a_pe <- modos == "A pé"   # vector lógico: TRUE / FALSE
a_pe
sum(a_pe)        # TRUE conta como 1, por isso isto conta quem vai a pé

# 4. Tipos de dados ------------------------------------------------
class(idades)    # "numeric"
class(modos)     # "character"
class(a_pe)      # "logical"

# 5. Funções e ajuda -----------------------------------------------
# Uma função recebe entradas (argumentos) e devolve um resultado.
round(3.14159, digits = 2)
?round           # abre a página de ajuda de round()
?mean

# 6. Valores em falta ----------------------------------------------
pontuacoes <- c(60, 72, NA, 48)
mean(pontuacoes)                 # NA: o R não adivinha o valor em falta
mean(pontuacoes, na.rm = TRUE)   # retira os NA antes de calcular

# ==============================================================
# EXERCÍCIOS
# 1. Crie um objecto chamado distancia com os valores 0.5, 1.2, 3.4, 2.0 e 0.8 (km).
#    Atenção: no R o separador decimal é sempre o ponto (.), não a vírgula.
# 2. Calcule a média e a distância máxima.
# 3. Quantas distâncias são maiores do que 1 km? (Dica: distancia > 1, depois sum())
# 4. Converta as distâncias para metros e guarde-as em distancia_m.
# 5. Veja a página de ajuda de sd(). O que calcula?
# ==============================================================

# SOLUÇÕES (tente primeiro!)
distancia <- c(0.5, 1.2, 3.4, 2.0, 0.8)
mean(distancia); max(distancia)
sum(distancia > 1)
distancia_m <- distancia * 1000
distancia_m
sd(distancia)   # desvio padrão: dispersão média em torno da média
