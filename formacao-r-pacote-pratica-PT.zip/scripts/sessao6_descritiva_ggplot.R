# ==============================================================
# Sessão 6: Estatística descritiva e gráficos com ggplot2
# ==============================================================
library(tidyverse)
inquerito <- read_csv("dados/inquerito_escolar_ficticio.csv") |>
  mutate(modo_transporte = fct_infreq(modo_transporte))  # ordena os modos do mais ao menos frequente

# 1. Descrever uma variável numérica ---------------------------------------------
inquerito |>
  summarise(n       = sum(!is.na(distancia_km)),
            media   = mean(distancia_km, na.rm = TRUE),
            mediana = median(distancia_km, na.rm = TRUE),
            dp      = sd(distancia_km, na.rm = TRUE),
            q1      = quantile(distancia_km, 0.25, na.rm = TRUE),
            q3      = quantile(distancia_km, 0.75, na.rm = TRUE),
            minimo  = min(distancia_km, na.rm = TRUE),
            maximo  = max(distancia_km, na.rm = TRUE))
# Média > mediana: algumas distâncias longas puxam a média para cima (distribuição assimétrica à direita).

# 2. Descrever uma variável categórica: frequências e percentagens -----------------
inquerito |>
  count(modo_transporte) |>
  mutate(percentagem = round(100 * n / sum(n), 1))

# Tabela cruzada com percentagens por linha (percentagem dentro de cada local)
inquerito |>
  count(local, modo_transporte) |>
  group_by(local) |>
  mutate(percentagem = round(100 * n / sum(n), 1)) |>
  ungroup()

# 3. ggplot2: dados + estética (aes) + geometria (geom) ------------------------------
# Histograma: forma de uma variável numérica
ggplot(inquerito, aes(x = distancia_km)) +
  geom_histogram(binwidth = 0.5) +
  labs(x = "Distância à escola (km)", y = "Número de alunos")

# Caixa de bigodes (boxplot): comparar uma variável numérica entre grupos
ggplot(inquerito, aes(x = local, y = tempo_viagem_min)) +
  geom_boxplot() +
  labs(x = NULL, y = "Tempo de viagem (minutos)")

# Gráfico de barras com percentagens por local
inquerito |>
  count(local, modo_transporte) |>
  group_by(local) |>
  mutate(percentagem = 100 * n / sum(n)) |>
  ggplot(aes(x = modo_transporte, y = percentagem)) +
  geom_col() +
  facet_wrap(~ local) +
  coord_flip() +
  labs(x = NULL, y = "Percentagem de alunos")

# Diagrama de dispersão: relação entre duas variáveis numéricas
ggplot(inquerito, aes(x = distancia_km, y = tempo_viagem_min, colour = modo_transporte)) +
  geom_point(alpha = 0.7) +
  labs(x = "Distância (km)", y = "Tempo de viagem (min)", colour = "Modo")

# 4. Guardar um gráfico ----------------------------------------------------------------
dir.create("resultados", showWarnings = FALSE)
ggsave("resultados/tempo_por_local.png", width = 15, height = 10, units = "cm", dpi = 300,
       plot = ggplot(inquerito, aes(local, tempo_viagem_min)) + geom_boxplot())

# ==============================================================
# EXERCÍCIOS
# 1. Calcule a média, a mediana e o desvio padrão de bem_estar por sexo.
# 2. Faça um histograma de bem_estar com um painel por local (facet_wrap).
# 3. Faça um gráfico de barras de quer_bicicleta (Sim/Não) por sexo, com fill = quer_bicicleta
#    e position = "fill" para mostrar proporções.
# ==============================================================

# SOLUÇÕES
inquerito |>
  group_by(sexo) |>
  summarise(media = mean(bem_estar, na.rm = TRUE),
            mediana = median(bem_estar, na.rm = TRUE),
            dp = sd(bem_estar, na.rm = TRUE))
ggplot(inquerito, aes(bem_estar)) + geom_histogram(binwidth = 8) + facet_wrap(~ local)
ggplot(inquerito, aes(x = sexo, fill = quer_bicicleta)) +
  geom_bar(position = "fill") +
  labs(y = "Proporção", fill = "Iria de bicicleta?")
