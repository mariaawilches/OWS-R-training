# ==============================================================
# Sessão 7: Análise quantitativa básica (inferência)
# Lembre-se: estes dados são FICTÍCIOS. Os resultados só ilustram os métodos.
# ==============================================================
library(tidyverse)
inquerito <- read_csv("dados/inquerito_escolar_ficticio.csv")

# 1. Amostra vs população: uma estimativa varia de amostra para amostra ------
set.seed(1)
replicate(5, mean(sample(inquerito$tempo_viagem_min, 30)))   # 5 amostras de 30 alunos

# 2. Intervalo de confiança para uma média -------------------------------------
t.test(inquerito$bem_estar)$conf.int     # IC 95% para o bem-estar médio

# 3. Intervalo de confiança para uma proporção ----------------------------------
a_pe <- sum(inquerito$modo_transporte == "A pé")
prop.test(a_pe, nrow(inquerito))          # proporção que vai a pé, com IC 95%

# 4. Comparar duas médias: teste t ------------------------------------------------
# Pergunta: o bem-estar médio é diferente entre raparigas e rapazes?
inquerito |> group_by(sexo) |> summarise(media = mean(bem_estar, na.rm = TRUE), n = n())
t.test(bem_estar ~ sexo, data = inquerito)    # teste t de Welch (não assume variâncias iguais)
# Alternativa não paramétrica quando a distribuição é muito assimétrica ou n é pequeno:
wilcox.test(bem_estar ~ sexo, data = inquerito)

# 5. Duas variáveis categóricas: teste do qui-quadrado -------------------------------
# Pergunta: a vontade de ir de bicicleta está associada ao local?
tab <- table(inquerito$local, inquerito$quer_bicicleta)
tab
prop.table(tab, margin = 1)               # proporções por linha
chisq.test(tab)
chisq.test(tab)$expected                  # todas as frequências esperadas devem ser >= 5
# Se as frequências esperadas forem pequenas, use o teste exacto de Fisher:
fisher.test(tab)

# 6. Duas variáveis numéricas: correlação ------------------------------------------
cor(inquerito$distancia_km, inquerito$tempo_viagem_min, use = "complete.obs")
cor.test(inquerito$distancia_km, inquerito$tempo_viagem_min)

# 7. Regressão linear simples ---------------------------------------------------------
modelo <- lm(tempo_viagem_min ~ distancia_km, data = inquerito)
summary(modelo)
confint(modelo)
# Interpretação: cada km a mais está associado a cerca de <declive> minutos a mais de viagem.

ggplot(inquerito, aes(distancia_km, tempo_viagem_min)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm")

# Verificar os resíduos (devem parecer ruído aleatório em torno de 0)
plot(modelo, which = 1)

# ==============================================================
# EXERCÍCIOS
# 1. Calcule o IC 95% da distância média em cada local. Os intervalos sobrepõem-se?
# 2. Sentir-se seguro (sente_seguro >= 4) está associado ao sexo? Faça a tabela e o teste.
# 3. Ajuste lm(bem_estar ~ sente_seguro) e interprete o declive numa frase.
#    Pode concluir que sentir-se seguro CAUSA mais bem-estar? Porque não?
# ==============================================================

# SOLUÇÕES
inquerito |>
  filter(!is.na(distancia_km)) |>
  group_by(local) |>
  summarise(media = mean(distancia_km),
            inferior = t.test(distancia_km)$conf.int[1],
            superior = t.test(distancia_km)$conf.int[2])
inquerito <- inquerito |> mutate(seguro = if_else(sente_seguro >= 4, "Seguro", "Não seguro"))
tab2 <- table(inquerito$sexo, inquerito$seguro); tab2
chisq.test(tab2)
summary(lm(bem_estar ~ sente_seguro, data = inquerito))
# Dados observacionais transversais mostram associação, não causalidade (confusão, causalidade inversa).
