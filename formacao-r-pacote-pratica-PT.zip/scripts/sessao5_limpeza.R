# ==============================================================
# Sessão 5: Limpar e reorganizar um ficheiro Excel desorganizado
# Regra de ouro: nunca edite o ficheiro original. Limpe-o com código e guarde um ficheiro novo.
# ==============================================================
library(tidyverse)
library(readxl)

caminho <- "dados/inquerito_escolar_ficticio_desorganizado.xlsx"

# 1. Ler as duas folhas e juntá-las, criando o local a partir do nome da folha ----
bruto <- excel_sheets(caminho) |>
  set_names() |>
  map(\(folha) read_excel(caminho, sheet = folha, col_types = "text")) |>
  list_rbind(names_to = "local")
glimpse(bruto)

# 2. Mudar os nomes das colunas para nomes curtos (sem espaços nem acentos) ----
limpo <- bruto |>
  rename(id               = `ID Aluno`,
         sexo             = Sexo,
         idade            = `Idade (anos)`,
         modo_transporte  = `Modo de transporte`,
         distancia_km     = `Distância à escola (km)`,
         tempo_viagem_min = `Tempo de viagem (min)`,
         sente_seguro     = `Sente-se seguro (1-5)`,
         bem_estar        = `Bem-estar (0-100)`,
         quer_bicicleta   = `Iria de bicicleta?`,
         tamanho_agregado = `Tamanho do agregado`,
         data_inquerito   = `Data do inquérito`)

# 3. Retirar linhas duplicadas -------------------------------------------------
nrow(limpo)
limpo <- distinct(limpo)
nrow(limpo)
anyDuplicated(limpo$id)   # 0 = cada aluno aparece uma vez

# 4. Inspeccionar as categorias antes de recodificar ----------------------------
count(limpo, modo_transporte)
count(limpo, sexo)

# 5. Recodificar texto inconsistente --------------------------------------------
limpo <- limpo |>
  mutate(modo_transporte = str_trim(modo_transporte),
         modo_transporte = case_when(
           str_to_lower(modo_transporte) %in% c("a pé", "a pe", "pé") ~ "A pé",
           TRUE ~ modo_transporte),
         sexo = case_when(str_to_lower(sexo) %in% c("rapariga", "f") ~ "Rapariga",
                          TRUE ~ sexo))
count(limpo, modo_transporte)
count(limpo, sexo)

# 6. Códigos de valores em falta e números guardados como texto ------------------
limpo <- limpo |>
  mutate(idade            = parse_number(idade),          # "14 anos" -> 14
         distancia_km     = na_if(distancia_km, "-"),
         bem_estar        = na_if(bem_estar, "99"),       # 99 = não respondeu (ver livro de códigos)
         across(c(distancia_km, tempo_viagem_min, sente_seguro, bem_estar, tamanho_agregado),
                as.numeric),
         data_inquerito   = as.Date(data_inquerito))
glimpse(limpo)
summary(limpo)

# 7. Comparar com o ficheiro limpo fornecido com o curso ----------------------------
referencia <- read_csv("dados/inquerito_escolar_ficticio.csv")
limpo <- limpo |> select(names(referencia)) |> arrange(id)
all.equal(as.data.frame(limpo), as.data.frame(arrange(referencia, id)), check.attributes = FALSE)

# 8. Guardar os dados limpos (ficheiro novo; o original fica intacto) ---------------
dir.create("resultados", showWarnings = FALSE)
write_excel_csv(limpo, "resultados/inquerito_limpo.csv")   # abre bem no Excel, com acentos

# 9. Reorganizar: formato largo <-> longo ---------------------------------------------
resumo_largo <- limpo |>
  count(local, modo_transporte) |>
  pivot_wider(names_from = local, values_from = n, values_fill = 0)
resumo_largo
resumo_largo |> pivot_longer(-modo_transporte, names_to = "local", values_to = "n")

# ==============================================================
# EXERCÍCIOS
# 1. Crie um factor para modo_transporte com os níveis por esta ordem:
#    A pé, Bicicleta, Chapa, Carro ou mota, Outro. (Dica: factor(..., levels = ...))
# 2. Quantos alunos têm pelo menos um valor em falta? (Dica: filter(if_any(everything(), is.na)))
# 3. Guarde os dados limpos num ficheiro Excel com writexl::write_xlsx().
# ==============================================================

# SOLUÇÕES
limpo <- limpo |>
  mutate(modo_transporte = factor(modo_transporte,
                                  levels = c("A pé", "Bicicleta", "Chapa", "Carro ou mota", "Outro")))
levels(limpo$modo_transporte)
limpo |> filter(if_any(everything(), is.na)) |> nrow()
writexl::write_xlsx(limpo, "resultados/inquerito_limpo.xlsx")
