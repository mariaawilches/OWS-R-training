# ==============================================================
# Sessão 3: Compreender os dados (tipos, estrutura, dados arrumados)
# ==============================================================
library(tidyverse)
inquerito <- read_csv("dados/inquerito_escolar_ficticio.csv")

# 1. Unidade de observação: uma linha = um aluno ------------------------
nrow(inquerito)
n_distinct(inquerito$id)      # deve ser igual a nrow(): cada ID aparece uma vez

# 2. Tipos de variáveis --------------------------------------------------
glimpse(inquerito)
# Categórica (nominal):   local, sexo, modo_transporte, quer_bicicleta
# Categórica (ordinal):   sente_seguro (1 = nada seguro ... 5 = muito seguro)
# Numérica (discreta):    idade, tamanho_agregado
# Numérica (contínua):    distancia_km, tempo_viagem_min, bem_estar
# Data:                   data_inquerito

# 3. Resumos rápidos ------------------------------------------------------
summary(inquerito)            # mínimo, quartis, média, máximo, número de NA
table(inquerito$modo_transporte)
table(inquerito$local, inquerito$modo_transporte)

# 4. Factores: variáveis categóricas com um conjunto fixo de níveis -------
inquerito <- inquerito |>
  mutate(sente_seguro_f = factor(sente_seguro, levels = 1:5,
                                 labels = c("Nada seguro", "Pouco seguro", "Neutro",
                                            "Seguro", "Muito seguro"),
                                 ordered = TRUE))
table(inquerito$sente_seguro_f)

# 5. Valores em falta -------------------------------------------------------
colSums(is.na(inquerito))     # número de NA em cada coluna

# 6. Dados arrumados (tidy data) -----------------------------------------------
# Arrumado = cada variável é uma coluna, cada observação é uma linha,
# cada valor é uma célula. O ficheiro do inquérito já está arrumado.
# Exemplo NÃO arrumado: uma coluna por local
largo <- tibble(modo = c("A pé", "Bicicleta"),
                `Chamanculo C` = c(135, 6),
                Macaneta = c(28, 21))
largo
# Arrumar: o local passa a ser uma variável
largo |> pivot_longer(cols = -modo, names_to = "local", values_to = "alunos")

# ==============================================================
# EXERCÍCIOS
# 1. Que variável identifica cada aluno? Verifique que não tem duplicados.
# 2. Para cada variável, escreva o seu tipo (nominal, ordinal, discreta, contínua, data).
# 3. Quantos alunos têm a pontuação de bem-estar em falta?
# 4. Faça uma tabela de frequências de quer_bicicleta por local.
# ==============================================================

# SOLUÇÕES
anyDuplicated(inquerito$id)   # 0 significa que não há duplicados
sum(is.na(inquerito$bem_estar))
table(inquerito$local, inquerito$quer_bicicleta)
