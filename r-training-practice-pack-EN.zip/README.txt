R TRAINING PRACTICE PACK (OWS MOZAMBIQUE TEAM)
=============================================

ALL DATA IN THIS PACK ARE FICTITIOUS. They were simulated by computer to look
like a school travel survey. They do not describe any real student, school or
community, and no result from them should be quoted as a finding.

How to start
1. Unzip this folder somewhere easy to find (for example Documents/r-training).
2. Double-click r-training.Rproj. RStudio opens with this folder as the
   working directory, so the code finds the data/ folder.
3. Open the script for the session from the Files pane (scripts/ folder).
4. Session 8 uses session8_report.qmd, which sits in the main folder.

Folders
data/      the practice data (never edit these files by hand)
scripts/   one script per session, with exercises and solutions at the end
output/    created by the scripts for cleaned data and graphs

FILES
school_survey_fake.csv          clean survey data, 240 students, 12 variables
school_survey_fake_messy.xlsx   the same data with typical problems, one sheet per site
measurements_fake.csv           height and weight for 205 IDs (200 match the survey)

CODEBOOK: school_survey_fake.csv
Variable          Type                    Description / values
id                text (key)              Student ID. CH = Chamanculo C, MC = Macaneta
site              categorical, nominal    Chamanculo C; Macaneta
sex               categorical, nominal    Girl; Boy
age               numeric, discrete       Age in completed years
travel_mode       categorical, nominal    Usual mode to school: Walking; Bicycle;
                                          Chapa (minibus); Car or motorbike; Other
distance_km       numeric, continuous     Home to school distance in km (blank = missing)
travel_time_min   numeric, continuous     Usual travel time in minutes
feels_safe        categorical, ordinal    "I feel safe on my way to school":
                                          1 very unsafe, 2 unsafe, 3 neutral, 4 safe, 5 very safe
wellbeing         numeric, 0 to 100       Well-being score, higher = better (blank = missing)
would_cycle       categorical, nominal    Would cycle to school if it were possible: Yes; No
household_size    numeric, discrete       Number of people living in the household
survey_date       date                    Date of interview (YYYY-MM-DD)

Messy file only: well-being 99 = not answered; distance "-" = not known.

CODEBOOK: measurements_fake.csv
id          text (key)            Student ID (5 IDs do not exist in the survey, on purpose)
height_cm   numeric, continuous   Height in centimetres
weight_kg   numeric, continuous   Weight in kilograms

Packages used: tidyverse, readxl, writexl (install once with
install.packages(c("tidyverse", "readxl", "writexl"))).
