# ==============================================================
# Session 2: Projects, packages and importing data
# Before running: open the RStudio project r-training.Rproj
# (File > Open Project) so that the data/ folder is found.
# ==============================================================

# 1. Install packages (only ONCE per computer; needs internet) -----
# Remove the # at the start of the next line the first time you run it.
# install.packages(c("tidyverse", "readxl", "writexl"))

# 2. Load packages (EVERY time you open R) --------------------------
library(tidyverse)   # includes readr, dplyr, ggplot2, tidyr, forcats...
library(readxl)      # to read Excel files

# 3. Where am I? -----------------------------------------------------
getwd()               # the working directory (the project folder)
list.files("data")    # files inside the data folder

# 4. Import a CSV file -------------------------------------------------
survey <- read_csv("data/school_survey_fake.csv")

# 5. Look at the data ---------------------------------------------------
survey              # prints the first rows
glimpse(survey)     # one line per variable, with its type
View(survey)        # opens a spreadsheet-like viewer (do not edit there)
nrow(survey); ncol(survey)
names(survey)

# 6. Import an Excel file ------------------------------------------------
excel_sheets("data/school_survey_fake_messy.xlsx")    # list the sheets
messy_ch <- read_excel("data/school_survey_fake_messy.xlsx", sheet = "Chamanculo C")
glimpse(messy_ch)   # notice the long column names and text in numeric columns

# 7. Import the second table (measurements) -----------------------------
measures <- read_csv("data/measurements_fake.csv")
glimpse(measures)

# ==============================================================
# EXERCISES
# 1. Import the "Macaneta" sheet of the messy Excel file into an object called messy_mc.
# 2. How many rows and columns does it have?
# 3. Which columns did R read as text (<chr>) although they should be numbers? Why?
# 4. Use the $ sign to extract the age column of survey and calculate its mean.
# ==============================================================

# SOLUTIONS
messy_mc <- read_excel("data/school_survey_fake_messy.xlsx", sheet = "Macaneta")
dim(messy_mc)
glimpse(messy_mc)   # e.g. "Distance to school (km)" contains "-", well-being contains 99
mean(survey$age)
