# ==============================================================
# Session 5: Cleaning and reshaping a messy Excel file
# Golden rule: never edit the raw file. Clean it with code, then save a new file.
# ==============================================================
library(tidyverse)
library(readxl)

path <- "data/school_survey_fake_messy.xlsx"

# 1. Read both sheets and stack them, adding the site from the sheet name ----
raw <- excel_sheets(path) |>
  set_names() |>
  map(\(sheet) read_excel(path, sheet = sheet, col_types = "text")) |>
  list_rbind(names_to = "site")
glimpse(raw)

# 2. Rename columns to short, consistent names (no spaces, no accents) ------
clean <- raw |>
  rename(id              = `Student ID`,
         sex             = Sex,
         age             = `Age (years)`,
         travel_mode     = `Mode of transport`,
         distance_km     = `Distance to school (km)`,
         travel_time_min = `Travel time (min)`,
         feels_safe      = `Feels safe (1-5)`,
         wellbeing       = `Well-being score (0-100)`,
         would_cycle     = `Would cycle to school?`,
         household_size  = `Household size`,
         survey_date     = `Survey date`)

# 3. Remove exact duplicate rows ---------------------------------------------
nrow(clean)
clean <- distinct(clean)
nrow(clean)
anyDuplicated(clean$id)   # 0 = each student appears once

# 4. Inspect categories before recoding -------------------------------------
count(clean, travel_mode)
count(clean, sex)

# 5. Recode inconsistent text -----------------------------------------------
clean <- clean |>
  mutate(travel_mode = str_trim(travel_mode),
         travel_mode = case_when(
           str_to_lower(travel_mode) %in% c("walking", "walk", "on foot") ~ "Walking",
           TRUE ~ travel_mode),
         sex = case_when(str_to_lower(sex) %in% c("girl", "f") ~ "Girl",
                         TRUE ~ sex))
count(clean, travel_mode)
count(clean, sex)

# 6. Missing-value codes and numbers stored as text --------------------------
clean <- clean |>
  mutate(age             = parse_number(age),        # "14 years" -> 14
         distance_km     = na_if(distance_km, "-"),
         wellbeing       = na_if(wellbeing, "99"),   # 99 = not answered (see codebook)
         across(c(distance_km, travel_time_min, feels_safe, wellbeing, household_size),
                as.numeric),
         survey_date     = as.Date(survey_date))
glimpse(clean)
summary(clean)

# 7. Check against the clean file supplied with the course -------------------
reference <- read_csv("data/school_survey_fake.csv")
clean <- clean |> select(names(reference)) |> arrange(id)
all.equal(as.data.frame(clean), as.data.frame(arrange(reference, id)), check.attributes = FALSE)

# 8. Save the cleaned data (a new file; the raw file stays untouched) --------
dir.create("output", showWarnings = FALSE)
write_csv(clean, "output/school_survey_clean.csv")

# 9. Reshaping: wide <-> long -------------------------------------------------
summary_wide <- clean |>
  count(site, travel_mode) |>
  pivot_wider(names_from = site, values_from = n, values_fill = 0)
summary_wide
summary_wide |> pivot_longer(-travel_mode, names_to = "site", values_to = "n")

# ==============================================================
# EXERCISES
# 1. Create a factor variable for travel_mode with the levels in this order:
#    Walking, Bicycle, Chapa (minibus), Car or motorbike, Other. (Hint: factor(..., levels = ...))
# 2. How many students have at least one missing value? (Hint: filter(if_any(everything(), is.na)))
# 3. Save the cleaned data as an Excel file with writexl::write_xlsx().
# ==============================================================

# SOLUTIONS
clean <- clean |>
  mutate(travel_mode = factor(travel_mode,
                              levels = c("Walking", "Bicycle", "Chapa (minibus)", "Car or motorbike", "Other")))
levels(clean$travel_mode)
clean |> filter(if_any(everything(), is.na)) |> nrow()
writexl::write_xlsx(clean, "output/school_survey_clean.xlsx")
