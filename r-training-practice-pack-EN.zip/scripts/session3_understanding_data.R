# ==============================================================
# Session 3: Understanding data (types, structure, tidy data)
# ==============================================================
library(tidyverse)
survey <- read_csv("data/school_survey_fake.csv")

# 1. Unit of observation: one row = one student ------------------------
nrow(survey)
n_distinct(survey$id)       # should equal nrow(): each ID appears once

# 2. Types of variables ---------------------------------------------------
glimpse(survey)
# Categorical (nominal):  site, sex, travel_mode, would_cycle
# Categorical (ordinal):  feels_safe (1 = very unsafe ... 5 = very safe)
# Numeric (discrete):     age, household_size
# Numeric (continuous):   distance_km, travel_time_min, wellbeing
# Date:                   survey_date

# 3. Quick summaries ------------------------------------------------------
summary(survey)              # min, quartiles, mean, max, number of NA
table(survey$travel_mode)
table(survey$site, survey$travel_mode)

# 4. Factors: categorical variables with a fixed set of levels ----------
survey <- survey |>
  mutate(feels_safe_f = factor(feels_safe, levels = 1:5,
                               labels = c("Very unsafe", "Unsafe", "Neutral", "Safe", "Very safe"),
                               ordered = TRUE))
table(survey$feels_safe_f)

# 5. Missing values ---------------------------------------------------------
colSums(is.na(survey))       # number of NA in each column

# 6. Tidy data -------------------------------------------------------------
# Tidy = each variable is a column, each observation is a row,
# each value is a cell. The survey file is already tidy.
# A NON-tidy example: one column per site
wide <- tibble(mode = c("Walking", "Bicycle"),
               `Chamanculo C` = c(135, 6),
               Macaneta = c(28, 21))
wide
# Making it tidy: site becomes a variable
wide |> pivot_longer(cols = -mode, names_to = "site", values_to = "students")

# ==============================================================
# EXERCISES
# 1. Which variable could be used to identify each student? Check it has no duplicates.
# 2. For each variable, write down its type (nominal, ordinal, discrete, continuous, date).
# 3. How many students have a missing well-being score?
# 4. Make a frequency table of would_cycle by site.
# ==============================================================

# SOLUTIONS
anyDuplicated(survey$id)     # 0 means no duplicates
sum(is.na(survey$wellbeing))
table(survey$site, survey$would_cycle)
