# ==============================================================
# Session 1: First steps in R and RStudio
# OWS Mozambique R training (practice script)
# Run each line with Ctrl+Enter (Windows) or Cmd+Enter (Mac).
# Lines that start with # are comments: R ignores them.
# ==============================================================

# 1. R as a calculator ------------------------------------------
2 + 3
10 / 4
(5 + 3) * 2
sqrt(81)          # square root
15 %% 4           # remainder of a division

# 2. Objects: storing values with <- -------------------------------
students <- 240
girls <- 117
girls / students              # proportion of girls
prop_girls <- girls / students
round(prop_girls * 100, 1)    # percentage, 1 decimal place

# 3. Vectors: several values in one object ------------------------
ages <- c(13, 14, 14, 15, 17, 16, 13)
length(ages)     # how many values
mean(ages)       # average
median(ages)
min(ages); max(ages)
ages + 1         # operations apply to every value

modes <- c("Walking", "Walking", "Chapa (minibus)", "Bicycle", "Walking")
table(modes)     # counts of each category

walks <- modes == "Walking"   # logical vector: TRUE / FALSE
walks
sum(walks)       # TRUE counts as 1, so this counts walkers

# 4. Types of data -------------------------------------------------
class(ages)      # "numeric"
class(modes)     # "character"
class(walks)     # "logical"

# 5. Functions and help --------------------------------------------
# A function takes inputs (arguments) and returns an output.
round(3.14159, digits = 2)
?round           # opens the help page for round()
?mean

# 6. Missing values -------------------------------------------------
scores <- c(60, 72, NA, 48)
mean(scores)                 # NA: R will not guess the missing value
mean(scores, na.rm = TRUE)   # remove NA before calculating

# ==============================================================
# EXERCISES
# 1. Create an object called distance with the values 0.5, 1.2, 3.4, 2.0 and 0.8 (km).
# 2. Calculate the mean and the maximum distance.
# 3. How many distances are greater than 1 km? (Hint: distance > 1, then sum())
# 4. Convert the distances to metres and store them in distance_m.
# 5. Look at the help page of sd(). What does it calculate?
# ==============================================================

# SOLUTIONS (try first!)
distance <- c(0.5, 1.2, 3.4, 2.0, 0.8)
mean(distance); max(distance)
sum(distance > 1)
distance_m <- distance * 1000
distance_m
sd(distance)   # standard deviation: average spread around the mean
