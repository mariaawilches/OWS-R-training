# ==============================================================
# Session 6: Descriptive statistics and graphs with ggplot2
# ==============================================================
library(tidyverse)
survey <- read_csv("data/school_survey_fake.csv") |>
  mutate(travel_mode = fct_infreq(travel_mode))   # order modes from most to least common

# 1. Describing a numeric variable --------------------------------------------
survey |>
  summarise(n       = sum(!is.na(distance_km)),
            mean    = mean(distance_km, na.rm = TRUE),
            median  = median(distance_km, na.rm = TRUE),
            sd      = sd(distance_km, na.rm = TRUE),
            q1      = quantile(distance_km, 0.25, na.rm = TRUE),
            q3      = quantile(distance_km, 0.75, na.rm = TRUE),
            min     = min(distance_km, na.rm = TRUE),
            max     = max(distance_km, na.rm = TRUE))
# Mean > median here: a few long distances pull the mean up (right-skewed distribution).

# 2. Describing a categorical variable: counts and percentages ------------------
survey |>
  count(travel_mode) |>
  mutate(percent = round(100 * n / sum(n), 1))

# Cross-tabulation with row percentages (percent of each site)
survey |>
  count(site, travel_mode) |>
  group_by(site) |>
  mutate(percent = round(100 * n / sum(n), 1)) |>
  ungroup()

# 3. ggplot2: data + aesthetics (aes) + geometry (geom) -------------------------
# Histogram: shape of a numeric variable
ggplot(survey, aes(x = distance_km)) +
  geom_histogram(binwidth = 0.5) +
  labs(x = "Distance to school (km)", y = "Number of students")

# Boxplot: compare a numeric variable between groups
ggplot(survey, aes(x = site, y = travel_time_min)) +
  geom_boxplot() +
  labs(x = NULL, y = "Travel time (minutes)")

# Bar chart of percentages by site
survey |>
  count(site, travel_mode) |>
  group_by(site) |>
  mutate(percent = 100 * n / sum(n)) |>
  ggplot(aes(x = travel_mode, y = percent)) +
  geom_col() +
  facet_wrap(~ site) +
  coord_flip() +
  labs(x = NULL, y = "Percent of students")

# Scatter plot: relationship between two numeric variables
ggplot(survey, aes(x = distance_km, y = travel_time_min, colour = travel_mode)) +
  geom_point(alpha = 0.7) +
  labs(x = "Distance (km)", y = "Travel time (min)", colour = "Mode")

# 4. Save a graph -------------------------------------------------------------
dir.create("output", showWarnings = FALSE)
ggsave("output/time_by_site.png", width = 15, height = 10, units = "cm", dpi = 300,
       plot = ggplot(survey, aes(site, travel_time_min)) + geom_boxplot())

# ==============================================================
# EXERCISES
# 1. Calculate mean, median and standard deviation of wellbeing by sex.
# 2. Make a histogram of wellbeing with one panel per site (facet_wrap).
# 3. Make a bar chart of would_cycle (Yes/No) by sex, using fill = would_cycle
#    and position = "fill" to show proportions.
# ==============================================================

# SOLUTIONS
survey |>
  group_by(sex) |>
  summarise(mean = mean(wellbeing, na.rm = TRUE),
            median = median(wellbeing, na.rm = TRUE),
            sd = sd(wellbeing, na.rm = TRUE))
ggplot(survey, aes(wellbeing)) + geom_histogram(binwidth = 8) + facet_wrap(~ site)
ggplot(survey, aes(x = sex, fill = would_cycle)) +
  geom_bar(position = "fill") +
  labs(y = "Proportion", fill = "Would cycle?")
