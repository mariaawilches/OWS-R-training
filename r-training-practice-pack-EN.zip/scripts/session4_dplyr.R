# ==============================================================
# Session 4: Managing databases with dplyr
# The pipe |> reads as "and then". Shortcut: Ctrl+Shift+M
# ==============================================================
library(tidyverse)
survey   <- read_csv("data/school_survey_fake.csv")
measures <- read_csv("data/measurements_fake.csv")

# 1. select(): choose columns ------------------------------------------
survey |> select(id, site, sex, travel_mode)
survey |> select(-survey_date)                 # everything except survey_date

# 2. filter(): choose rows ------------------------------------------------
survey |> filter(site == "Macaneta")
survey |> filter(travel_mode == "Walking", distance_km > 2)
survey |> filter(travel_mode %in% c("Bicycle", "Walking"))
survey |> filter(!is.na(wellbeing))

# 3. arrange(): sort rows --------------------------------------------------
survey |> arrange(desc(travel_time_min))

# 4. mutate(): create or change columns -----------------------------------
survey <- survey |>
  mutate(speed_kmh  = distance_km / (travel_time_min / 60),
         active     = if_else(travel_mode %in% c("Walking", "Bicycle"), "Active", "Not active"),
         age_group  = case_when(age <= 12 ~ "10-12",
                                age <= 15 ~ "13-15",
                                TRUE      ~ "16-18"))

# 5. count(), group_by() and summarise() ------------------------------------
survey |> count(site, travel_mode)
survey |> count(site, active) |>
  group_by(site) |>
  mutate(percent = round(100 * n / sum(n), 1))

survey |>
  group_by(site, sex) |>
  summarise(students       = n(),
            mean_distance  = mean(distance_km, na.rm = TRUE),
            median_time    = median(travel_time_min),
            mean_wellbeing = mean(wellbeing, na.rm = TRUE),
            .groups = "drop")

# 6. Joins: combine two tables using a key (id) -------------------------------
nrow(survey); nrow(measures)
both <- survey |> inner_join(measures, by = "id")   # only IDs in both tables
all_survey <- survey |> left_join(measures, by = "id")  # all survey rows; NA if no measures
not_found <- measures |> anti_join(survey, by = "id")   # measures with no survey record
not_found

all_survey <- all_survey |>
  mutate(bmi = weight_kg / (height_cm / 100)^2)
summary(all_survey$bmi)

# ==============================================================
# EXERCISES
# 1. Keep only girls in Chamanculo C who travel by chapa. How many are there?
# 2. Create a variable time_cat: "Up to 15 min", "16-30 min", "More than 30 min".
# 3. For each travel mode, calculate the number of students and the mean travel time.
#    Sort from the longest to the shortest mean time.
# 4. How many survey students have no measurements? (Hint: is.na(height_cm))
# ==============================================================

# SOLUTIONS
survey |> filter(site == "Chamanculo C", sex == "Girl", travel_mode == "Chapa (minibus)") |> nrow()
survey <- survey |>
  mutate(time_cat = case_when(travel_time_min <= 15 ~ "Up to 15 min",
                              travel_time_min <= 30 ~ "16-30 min",
                              TRUE                  ~ "More than 30 min"))
survey |> count(time_cat)
survey |>
  group_by(travel_mode) |>
  summarise(students = n(), mean_time = mean(travel_time_min)) |>
  arrange(desc(mean_time))
sum(is.na(all_survey$height_cm))
