# ==============================================================
# Session 7: Basic quantitative analysis (inference)
# Remember: these are FICTITIOUS data. The results only illustrate methods.
# ==============================================================
library(tidyverse)
survey <- read_csv("data/school_survey_fake.csv")

# 1. Sample vs population: a sample estimate varies from sample to sample ----
set.seed(1)
replicate(5, mean(sample(survey$travel_time_min, 30)))   # 5 samples of 30 students

# 2. Confidence interval for a mean -----------------------------------------
t.test(survey$wellbeing)$conf.int      # 95% CI for mean well-being

# 3. Confidence interval for a proportion ------------------------------------
walkers <- sum(survey$travel_mode == "Walking")
prop.test(walkers, nrow(survey))       # proportion who walk, with 95% CI

# 4. Comparing two means: t-test ------------------------------------------------
# Question: is mean well-being different between girls and boys?
survey |> group_by(sex) |> summarise(mean = mean(wellbeing, na.rm = TRUE), n = n())
t.test(wellbeing ~ sex, data = survey)   # Welch t-test (does not assume equal variances)
# Non-parametric alternative when the distribution is very skewed or n is small:
wilcox.test(wellbeing ~ sex, data = survey)

# 5. Two categorical variables: chi-square test ---------------------------------
# Question: is willingness to cycle associated with site?
tab <- table(survey$site, survey$would_cycle)
tab
prop.table(tab, margin = 1)            # row proportions
chisq.test(tab)
chisq.test(tab)$expected               # all expected counts should be >= 5
# If expected counts are small, use Fisher's exact test:
fisher.test(tab)

# 6. Two numeric variables: correlation -------------------------------------------
cor(survey$distance_km, survey$travel_time_min, use = "complete.obs")
cor.test(survey$distance_km, survey$travel_time_min)

# 7. Simple linear regression ------------------------------------------------------
model <- lm(travel_time_min ~ distance_km, data = survey)
summary(model)
confint(model)
# Interpretation: each extra km is associated with about <slope> more minutes of travel.

ggplot(survey, aes(distance_km, travel_time_min)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm")

# Check the residuals (should look like random noise around 0)
plot(model, which = 1)

# ==============================================================
# EXERCISES
# 1. Calculate a 95% CI for mean distance in each site. Do the intervals overlap?
# 2. Is feeling safe (feels_safe >= 4) associated with sex? Make the table and test it.
# 3. Fit lm(wellbeing ~ feels_safe) and interpret the slope in one sentence.
#    Can you conclude that feeling safe CAUSES higher well-being? Why not?
# ==============================================================

# SOLUTIONS
survey |>
  filter(!is.na(distance_km)) |>
  group_by(site) |>
  summarise(mean = mean(distance_km),
            lower = t.test(distance_km)$conf.int[1],
            upper = t.test(distance_km)$conf.int[2])
survey <- survey |> mutate(safe = if_else(feels_safe >= 4, "Safe", "Not safe"))
tab2 <- table(survey$sex, survey$safe); tab2
chisq.test(tab2)
summary(lm(wellbeing ~ feels_safe, data = survey))
# Cross-sectional observational data show association, not causation (confounding, reverse causation).
